//Game made by Jamie Ip
//You can contact me at probablyjamie@gmail.com for distribution or comments
//Run the client to play and have fun!

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Client {
    private static Window window;
    private static Player player;
    public static String stage = "start";
    private static ActionListener al=new ActionListener(){public void actionPerformed(ActionEvent evt){String text=window.tf.getText().toLowerCase();window.tf.setText("");command(text);}};

    public Client() {
        window = new Window();
        player = new Player();
    }

    public static void main(String[] args) {
        Client client = new Client();
        window.tf.addActionListener(al);
        write("Type in Start to begin your story... \nCan you survive the night?");
        while (1==1) window.music();
    }

    public static void write(String text) {
        window.ta.setText(text);
    }

    public static void command(String text) {
        if (text.contains("aaron") || text.contains("felix")) {
            badEnd(9);
        }
        else if (text.contains("jamie")) {
            badEnd(10);
        }
        else if (text.contains("lance")) {
            write("You feel slightly shorter. \nYou're not sure why.");
        }
        else if (text.contains("zack") || text.contains("berger")) {
            window.ta.append("\nstinky");
        }
        else if (text.equals("imadirtycheatergimmethebestending")) {
            goodEnd(2);
        }
        else if (text.contains("mute")) {
            window.stopMusic();
        }
        else if (text.contains("music")) {
            window.playMusic();
        }
        else if (stage.equals("end")) {
            if (text.equals("yes") || text.contains("try")) {
                stage = "start";
                window.setBackground("images/Start.png");
                window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
                write("Type in Start to begin your story... \nCan you survive the night?");
                window.playMusic();
            }
        } else if (stage.equals("start")) {
            if (text.equals("start")) {
                firstChoice();
            } else {
                write("Type in Start to begin your story... \nCan you survive the night?\nPerhaps you didn't hear me. Type in \"start\" to begin. ");
            }
        } else if (stage.equals("first")) {
            if (text.contains("wait")) {
                write("You decide to stay put inside your car and wait until morning. \nAfter what feels like hours of waiting, you feel a shiver run down your spine. Was the car \nalways this cold? \nWhat do you choose to do? "
                        + "\n*Go out to seek help \n*Stay put in your car");
                stayCar();
            } else if (text.contains("go")) {
                goOut();
            } else if (text.contains("call")) {
                write("You bring out your phone to call the police, but it only lights up for a second before\ninstantly going black. \nStaring desperately at your dead phone, you feel a shiver run down your spine. Was the car \nalways this cold? \nWhat do you choose to do? "
                        + "\n*Go out to seek help \n*Stay put in your car");
                stayCar();
            }

        } else if (stage.equals("car")) {
            if (text.contains("stay")) {
                badEnd(1);
            } else if (text.contains("go")) {
                goOut();
            }
        } else if (stage.equals("out")) {
            if (text.contains("run")) {
                lost();
            } else if (text.contains("go")) {
                house();
            }
        } else if (stage.equals("lost")) {
            badEnd(2);
        } else if (stage.equals("house")) {
            if (text.contains("knock")) {
                write("You knock on the front door. \nIt slowly creaks open, revealing the desolate ruins of what was once a grand hall.\nCarefully stepping over rubble,"
                        + " you see what appears to be a library on the left, while the\ndoors in the middle lead to a living room. \nWhat do you do?\n*Go left, into the library\n*Go forward to the living room\n*Go up the staircase");
                front();        
            } else if (text.contains("go")) {
                side();
            }
        } else if (stage.equals("side")) {
            if (text.contains("go")) {
                sideIn();
            } else if (text.contains("return")) {
                house();
            }
        } else if (stage.equals("sidein")) {
            badEnd(3);
        } else if (stage.equals("front")) {
            if (text.contains("left")) {
                write("You go through the left door and enter what appears to be a library.\nEverything is covered in a thin layer of dust- no living creature has been here in a while. \nThree ragged books lying on the floor catch your attention."
                        + "\nWhat do you do?\n*Read the red book\n*Open the blue book\n*Pick up the green book\n*Return to the entryway");
                left();
            } else if (text.contains("forward")) {
                forward();
            } else if (text.contains("up")) {
                badEnd(4);
            }
        } else if (stage.equals("library")) {
            if (text.contains("read") || text.contains("red")) {
                book(1);
            } else if (text.contains("open") || text.contains("blue")) {
                book(2);
            } else if (text.contains("pick") ||text.contains("green")) {
                book(3);
            } else if (text.contains("return")) {
                write("You return to the entryway of the house. \nWhat do you do?\n*Go left, back into the library\n*Go forward to the living room\n*Go up the staircase");
                front();
            } else if ((text.contains("find") || text.contains("white")) && player.readAll()) {
                book(4);
            }
            
        } else if (stage.equals("reading")) {
            if (text.contains("put")) {
                left();
                if (player.getBooksRead() == 1)
                    write("You put down the book.\nFor some reason, staring at those old pages gave you a headache.\nYou might only be able to read one more book."
                        + "\nWhat do you do?\n*Read the red book\n*Open the blue book\n*Pick up the green book\n*Return to the entryway");
                else if (player.getBooksRead() == 2)
                    write("You drop the book and clutch your head.\nYour skull feels like its splitting open; any further reading might be dangerous."
                            + "\nWhat do you do?\n*Read the red book\n*Open the blue book\n*Pick up the green book\n*Return to the entryway");
            }
            
        }
        
        else if (stage.equals("livingRoom")) {
            if (text.contains("sit")) {
                write("You sit down in the armchair, sinking into its heavy cushions.\nSurprisingly comfortable.");
                ghostAppears();
            } else if (text.contains("examine") || text.contains("photograph")) {
                write("You examine the faded photograph in the middle of the room.\nIt features a happy little girl and a large, smiling dog.");
                ghostAppears();
            } else if (text.contains("try")) {
                if (player.readWhite()) {
                    happyGhost();
                } else {
                    write("You sit down to try playing the piano.\nThe keys are spotless, with not a trace of dust. You play a short song before stopping.");
                    ghostAppears();    
                }
            }
            
            
        } else if (stage.equals("ghostRoom")) {
            if (text.contains("talk")) {
                talk();
            } else if (text.contains("run")) {
                badEnd(6);
            } else if (text.contains("allison")) {
                if (player.readBlue()) goodEnd(1);
                else badEnd(8);
            }
            
        } else if (stage.equals("talk")) {
            if (text.contains("allison")) {
                if (player.readBlue()) goodEnd(1);
                else badEnd(8);
            } else {
                badEnd(7);
            }
        } else if (stage.equals("happyghost")) {
            if (text.contains("")) {
                goodEnd(2);
            }
        }
    }

    public static void firstChoice() {
        stage = "first";
        window.setBackground("images/SpookyForest2.jpg");
        window.ta.setFont(new Font("TimesRoman", Font.PLAIN, 20));
        write("You were driving back home, late at night, when your car suddenly breaks down in the \nmiddle of a forest. \nWhat do you choose to do? Type in the first word of your choice."
                + "\n*Wait in your car until morning \n*Go out to seek help \n*Call for help on your phone");

    }

    public static void goOut() {
        stage = "out";
        window.setBackground("images/SpookyForest.jpg");
        write("Leaving the safety of your car, you decide to go out and look for help. \nWandering through the eeriely quiet forest, you see a tiny pinprick of light "
                + "in the distance.\nWhat do you do?\n*Run away from the light!\n*Go towards the light and investigate");
    }

    public static void house() {
        stage = "house";
        window.setBackground("images/ForestHouse.jpg");
        write("You follow the light and eventually come across a clearing in the forest. \nThe light is coming from an old, foresaken house, built of rotting wood and covered in ivy."
                + "\nThe house has an ominous air around it, but perhaps you can find the help you're\nseeking inside.\nWhat do you do?\n*Knock on the front door\n*Go around the side");
    }

    public static void side() {
        stage = "side";
        window.setBackground("images/ForestHouse2.jpg");
        write("You go around the house and spy an open window near the back. \nLuckily, it looks like you can fit through it."
                + "\nWhat do you do?\n*Go in through the window\n*Return to the front");
    }

    public static void front() {
        stage = "front";
        window.setBackground("images/HouseEntry.jpg");
    }
    
    public static void left() {
        stage = "library";
        window.setBackground("images/HouseLibrary.jpg");
        
    }
    
    public static void book(int n) {
        stage = "reading";
        if (player.getBooksRead() == 2) badEnd(5);
        else if (n == 1) {
            player.readBook("red");
            window.setBackground("images/RedBook.jpg");
            write("You decide to read the red book.\nIt appears to be a manual on how to deal with supernatural creatures.\nYou see some strange, hurried writing in the corner... a message, maybe?\nWhat do you do?\n*Put down the book");
        } else if (n == 2) {
            player.readBook("blue");
            window.setBackground("images/BlueBook.jpg");
            write("You open the blue book to read.\nIt appears to be a diary, written by the past inhabitant of this house.\nThere are some seemingly random letters written in the corner of the book.\nWhat do you do?\n*Put down the book");
        } else if (n == 3) {
            player.readBook("green");
            window.setBackground("images/GreenBook.jpg");
            write("You pick up the green book and start reading.\nIt appears to be a children's book about fairytales, doodled on by a child.\nThere are some strange letters in the bottom right of the page, written in a different \nhandwriting.\nWhat do you do?\n*Put down the book");
        } else if (n == 4) {
            player.readBook("white");
            window.setBackground("images/WhiteBook.jpg");
            write("You rummage through stacks of dusty books to find an old, worn book with a white cover.\nYou open the book to find a single scribbled message and a piece of sheet music on the \nfollowing page.\nYou take the music with you- it might come in handy later."
                    + "\nWhat do you do?\n*Put down the book");
        }
    }
    
    public static void forward() {
        stage = "livingRoom";
        window.setBackground("images/HouseRoom.jpg");
        write("You go forward, pushing open the double doors to enter a cozy living room.\nA fire blazes in the hearth and a warmth lingers in the room- clearly, someone has been here recently."
                + "\nWhat do you do? \n*Sit down on an armchair\n*Examine the photograph in the center of the room\n*Try out the piano on the left");
    }
    
    public static void ghostRoom() {
        stage = "ghostRoom";
        window.setBackground("images/HouseRoom1.jpg");
    } 
    
    public static void talk() {
        stage = "talk";
        window.setBackground("images/HouseGhost.jpg");
        window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 25));
        write("The figure grins and speaks in the voice of a young girl;");
        if (player.getDeaths() == 0)
            window.ta.append("\n\"Zero deaths? I'm impressed.\nIt's almost as if you knew exactly what you were doing.\"");
        else if (player.getDeaths() == 1)
            window.ta.append("\n\"You got this far, only dying once? How impressive. \nUnfortunately, you're about to die again.\"");
        else window.ta.append("\n\"You've already died " + player.getDeaths() + " times... so what's one more going to matter?\"");
        window.ta.append("\nWhat do you do?");
    } 



    public static void stayCar() {
        stage = "car";
        window.setBackground("images/InsideCar1.jpg");
    }

    public static void lost() {
        stage = "lost";
        window.setBackground("images/SpookyForest3.jpg");
        write("Stricken by fear, you run away from the light as fast as you can.\nYou continue walking through the forest, which is getting darker and darker. \nYou begin to feel as if someone is watching you, and a cold sweat builds on your neck."
                + "\nLooking around in every direction, there are nothing but woods as far as the eye can see. \nWhat do you do?\n*Scream\n*Run away, as fast as you can\n*Try to hide");
    }

    public static void sideIn() {
        stage = "sidein";
        window.setBackground("images/HouseInside.jpg");
        write("You crawl through the window and find yourself in a tiny wooden room. \nThere is very little dust on the furniture and fresh footprints on the ground- signs that you are not alone."
                + "\nWhat do you do?\n*Investigate the items on the table\n*Sneak into the hallway\n*Examine the floor");
    }
    
    public static void ghostAppears() {
        window.setBackground("images/blackscreen.jpg");
        new java.util.Timer().schedule(new java.util.TimerTask() {
            @Override
            public void run() {
                ghostRoom();
                window.ta.append("\nYour eyes feel heavy... you close them for a second, and when you open them again, a white figure floats before you. \nAs you stare at the thing in front of you, your vision flickers in and out. You gulp.\nWhat do you do?"
                        + "\n*Talk to the thing\n*Run away");
                cancel();
            }
        }, 2000);
    }
    
    public static void happyGhost() {
        window.setBackground("images/houseRoom1.jpg");
        stage = "happyghost";
        write("You sit down and play the song you found in the white book.\nAs you play, you start hearing the sound of someone crying.\nA white figure appears before you, but it possesses no malice.\nWhat do you do?");
        
    }

    public static void badEnd(int n) {
        stage = "end";
        player.increaseDeaths();
        player.resetRead();
        if (n == 1) {
            window.setBackground("images/InsideCar2.jpg");
            write("You stubbornly remain inside your car, even as it gets colder and colder.\nYour teeth are chattering and your entire body is shivering - had the forest always been this\ndark? \nSuddenly, you hear a tapping at the window. "
                    + "You look up to see a shadowy figure\ngrinning at you, and as your frozen eyes slowly glaze over, everything goes black. \n\nTry again?");

        }
        if (n == 2) {
            window.setBackground("images/SpookyForest4.jpg");
            write("The forest remains silent, but the creatures within it grow bolder. \nTiny eyes stare at you from every direction.\nNone of them are friendly.\n\nTry again?");
        }

        if (n == 3) {
            window.setBackground("images/HouseInside2.jpg");
            write("A soft voice sounds from behind you; \n\"It's not very nice to break into other peoples's homes, you know?\"\nBefore you can do anything, you feel a tiny pinch at the back of your neck, and your body \ngoes numb. Helpless, you fall to "
                    + "the floor, the soft skittering of thousands of legs around you.\nA dark mass slowly engulfs your body, which is thankfully too numb to feel the thousands\nof spiders crawling over you. Before long, you can see nothing but black.\n\nTry again?");
        }
        
        if (n==4) {
            window.setBackground("images/HouseCeiling.jpg");
            write("You decide to climb the staircase, which creaks with every step.\nHalfway up, you step on thin air - the staircase collapses beneath you.\nAs you hurtle to the ground, you catch a glimpse"
                    + " of a shadowy figure on the ceiling, staring at\nyou. It's the last thing you ever see. \n\nTry again?");
        }
        if (n==5) {
            window.setBackground("images/LibraryScare.jpg");
            write("As you pick up the third book, you are overcome with an immense, sudden sense of nausea. \nYou drop the book and crumple to the floor in immense pain.\nIs someone smiling at you? \n\nTry again?");
        }
        if (n==6) {
            window.setBackground("images/HouseRoom2.jpg");
            write("THERE IS NO ESCAPE. \nNO ESCAPE.\nNO ESCAPE.\nNO ESCAPE.\nNO ESCAPE.\nNO ESCAPE.\n\nTry again?");
        }
        if (n==7) {
            window.setBackground("images/Jumpscare1.jpg");
            window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
            write("Want to play forever?\n\nTry again?");
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    window.setBackground("images/HouseGhost2.jpg");
                    cancel();
                }
            }, 100);
        }
        if (n==8) {
            window.setBackground("images/Jumpscare1.jpg");
            window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
            write("\"How do you know my name, stranger?\"\n\nTry again?");
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    window.setBackground("images/HouseRoom2.jpg");
                    cancel();
                }
            }, 100);
            
        }
        if (n==9) {
            window.setBackground("images/404.png");
            window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
            write("Your game is suddenly infested with bugs.\nTh3 errorkks... they're everywh\\ere!\nWhat/\\ have you d\\one??\n\nRest@rt?");
        }
        if (n==10) {
            window.setBackground("images/Jumpscare2.jpg");
            window.ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
            write("Hello there.\nMan, this project took a while. It was fun though.\nTip: Put together the messages in the right corners of each \nbook in the library to get the happy end!\nRestart?");
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    window.setBackground("images/blackscreen.jpg");
                    cancel();
                }
            }, 500);
            
        }
        new java.util.Timer().schedule(new java.util.TimerTask() {
            @Override
            public void run() {
                if (stage == "end") {
                window.setBackground("images/youDied.jpg");
                cancel();
                }
            }
        }, 3000);
    }
    
    public static void goodEnd(int n) { //I don't know how else to do animation. I know this is really messy :P
        stage = "end";
        player.increaseWins();
        player.resetRead();
        window.stopMusic();
        if (n==1) {
            window.setBackground("images/GhostDying.jpg");
            window.ta.setFont(new Font("TimesRoman", Font.PLAIN, 23));
            write("With a ghastly scream, the ghost contorts and vanishes into a stream of fire.\nYou spend the rest of the night relaxing in the house until morning breaks.\nYou won!\nPlay again?");
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    window.setBackground("images/GhostDying2.jpg");
                    new java.util.Timer().schedule(new java.util.TimerTask() {
                        @Override
                        public void run() {
                            window.setBackground("images/GhostDying3.jpg");
                            new java.util.Timer().schedule(new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    window.setBackground("images/GhostDying4.jpg");
                                    new java.util.Timer().schedule(new java.util.TimerTask() {
                                        @Override
                                        public void run() {
                                            window.setBackground("images/GhostDying5.jpg");
                                            new java.util.Timer().schedule(new java.util.TimerTask() {
                                                @Override
                                                public void run() {
                                                    window.setBackground("images/GhostDying6.jpg");
                                                    new java.util.Timer().schedule(new java.util.TimerTask() {
                                                        @Override
                                                        public void run() {
                                                            window.setBackground("images/HouseRoom.jpg");
                                                            cancel();
                                                        }
                                                    }, 100);
                                                    cancel();
                                                }
                                            }, 200);
                                            cancel();
                                        }
                                    }, 200);
                                    cancel();
                                }
                            }, 200);
                            cancel();
                        }
                    }, 300);
                    cancel();
                }
            }, 300);
            if (player.getWins() == 2) {
                window.ta.append(" Have you heard about the secret ending? \nMaybe try rereading the books in the library.");
            }
        } else if (n==2) {
            window.setBackground("images/GhostCrying1.jpg");
            window.ta.setFont(new Font("TimesRoman", Font.PLAIN, 23));
            write("With a smile, the ghost fades away, leaving nothing behind.\nWith its spirit at rest, the house and its surrounding forest "
                    + "return to normalcy. \nYou have put an end to this haunted house and its reign of terror. \nCongratulations- you have completely won!");
            new java.util.Timer().schedule(new java.util.TimerTask() {
                @Override
                public void run() {
                    window.setBackground("images/GhostCrying2.jpg");
                    new java.util.Timer().schedule(new java.util.TimerTask() {
                        @Override
                        public void run() {
                            window.setBackground("images/GhostCrying3.jpg");
                            new java.util.Timer().schedule(new java.util.TimerTask() {
                                @Override
                                public void run() {
                                    window.setBackground("images/GhostCrying4.jpg");
                                    new java.util.Timer().schedule(new java.util.TimerTask() {
                                        @Override
                                        public void run() {
                                            window.setBackground("images/GhostCrying5.jpg");
                                            new java.util.Timer().schedule(new java.util.TimerTask() {
                                                @Override
                                                public void run() {
                                                    window.setBackground("images/GhostCrying6.jpg");
                                                    new java.util.Timer().schedule(new java.util.TimerTask() {
                                                        @Override
                                                        public void run() {
                                                            window.setBackground("images/GhostCrying7.jpg");
                                                            new java.util.Timer().schedule(new java.util.TimerTask() {
                                                                @Override
                                                                public void run() {
                                                                    window.setBackground("images/ForestLight.jpg");
                                                                    cancel();
                                                                }
                                                            }, 100);
                                                            cancel();
                                                        }
                                                    }, 100);
                                                    cancel();
                                                }
                                            }, 200);
                                            cancel();
                                        }
                                    }, 200);
                                    cancel();
                                }
                            }, 500);
                            cancel();
                        }
                    }, 200);
                    cancel();
                }
            }, 200);
        }
        
        
    }

}
