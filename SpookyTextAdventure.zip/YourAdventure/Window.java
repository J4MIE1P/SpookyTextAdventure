import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Window extends Canvas {

    private JFrame frame;
    private JPanel panel;
    public JTextArea ta;
    public JTextField tf;
    private JLabel label;
    private boolean playMusic = true;

    public Window() {   
        frame = new JFrame("Spooky Adventure");
        ImageIcon image = new ImageIcon("images/Start.png");
        label = new JLabel(image);
        panel = new JPanel(new BorderLayout());
        
        tf = new JTextField(20);
        tf.setFont(new Font("TimesRoman", Font.PLAIN, 24));
        
        ta = new JTextArea();
        ta.setFont(new Font("TimesRoman", Font.ITALIC, 30));
        ta.setEditable(false);
        ta.setLineWrap(true);

        panel.add(label, BorderLayout.NORTH);
        panel.add(ta, BorderLayout.CENTER);
        panel.add(tf, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setMinimumSize(new Dimension(750,700));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);     


    }
    
    public void setBackground(String file) {
        ImageIcon image = new ImageIcon(file);
        label.setIcon(image);
    }
    
    public void music() {
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(new File("Music/CreepyMusic.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            while (playMusic) {
                clip.loop(Clip.LOOP_CONTINUOUSLY);
            }
            clip.close();
        }
        catch(Exception e) {e.printStackTrace();}
    }
    
    public void stopMusic() {
        playMusic = false;
    }
    
    public void playMusic() {
        playMusic = true;
    }
}
