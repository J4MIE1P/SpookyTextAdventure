public class Player {

    private String name;
    private int deaths = 0;
    private int booksRead = 0;
    private int wins = 0;
    private boolean readRed = false;
    private boolean readBlue = false;
    private boolean readGreen = false;
    private boolean readWhite = false;
    
    public Player() {
    }
    
    public String getName() {
        return name;
    }
    
    public int getDeaths() {
        return deaths;
    }
    
    public void increaseDeaths() {
        deaths++;
    }
    
    public void resetRead() {
        booksRead = 0;
    }
    
    public void increaseWins() {
        wins++;
    }
    
    public int getWins() {
        return wins;
    }
    
    public boolean readWhite() {
        return (readWhite);
    }
    
    public boolean readBlue() {
        return (readBlue);
    }
    
    public boolean readAll() {
        return (readRed & readBlue & readGreen);
    }
    
    public void readBook(String color) {
        if (color.equals("red")) {
            readRed = true;
        } else if (color.equals("blue")) {
            readBlue = true;
        } else if (color.equals("green")) {
            readGreen = true;
        } else if (color.equals("white")) {
            readWhite = true;
        }
        booksRead++;
    }
    
    public int getBooksRead() {
        return booksRead;
    }
}
